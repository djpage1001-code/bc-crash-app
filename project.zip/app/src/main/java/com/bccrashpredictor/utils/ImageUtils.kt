package com.bccrashpredictor.utils

import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.Rect

/**
 * Utility functions for image processing
 */
object ImageUtils {
    
    /**
     * Convert bitmap to grayscale
     */
    fun toGrayscale(bitmap: Bitmap): Bitmap {
        val width = bitmap.width
        val height = bitmap.height
        val pixels = IntArray(width * height)
        
        bitmap.getPixels(pixels, 0, width, 0, 0, width, height)
        
        for (i in pixels.indices) {
            val pixel = pixels[i]
            val red = (pixel shr 16) and 0xFF
            val green = (pixel shr 8) and 0xFF
            val blue = pixel and 0xFF
            
            val gray = (0.299 * red + 0.587 * green + 0.114 * blue).toInt()
            
            pixels[i] = (gray shl 16) or (gray shl 8) or gray or 0xFF000000.toInt()
        }
        
        val grayBitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
        grayBitmap.setPixels(pixels, 0, width, 0, 0, width, height)
        
        return grayBitmap
    }
    
    /**
     * Apply threshold to bitmap
     */
    fun applyThreshold(bitmap: Bitmap, threshold: Int = 128): Bitmap {
        val width = bitmap.width
        val height = bitmap.height
        val pixels = IntArray(width * height)
        
        bitmap.getPixels(pixels, 0, width, 0, 0, width, height)
        
        for (i in pixels.indices) {
            val pixel = pixels[i]
            val gray = (pixel shr 16) and 0xFF
            
            val binary = if (gray > threshold) 255 else 0
            pixels[i] = (binary shl 16) or (binary shl 8) or binary or 0xFF000000.toInt()
        }
        
        val thresholdBitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
        thresholdBitmap.setPixels(pixels, 0, width, 0, 0, width, height)
        
        return thresholdBitmap
    }
    
    /**
     * Crop bitmap to specified region
     */
    fun cropBitmap(bitmap: Bitmap, region: Rect): Bitmap? {
        if (!region.isValid || 
            region.left < 0 || region.top < 0 || 
            region.right > bitmap.width || region.bottom > bitmap.height) {
            return null
        }
        
        return Bitmap.createBitmap(
            bitmap,
            region.left,
            region.top,
            region.width(),
            region.height()
        )
    }
    
    /**
     * Scale bitmap to specified dimensions
     */
    fun scaleBitmap(bitmap: Bitmap, width: Int, height: Int): Bitmap {
        return Bitmap.createScaledBitmap(bitmap, width, height, true)
    }
    
    /**
     * Calculate brightness of bitmap
     */
    fun calculateBrightness(bitmap: Bitmap): Double {
        val width = bitmap.width
        val height = bitmap.height
        val pixels = IntArray(width * height)
        
        bitmap.getPixels(pixels, 0, width, 0, 0, width, height)
        
        var totalBrightness = 0.0
        for (pixel in pixels) {
            val red = (pixel shr 16) and 0xFF
            val green = (pixel shr 8) and 0xFF
            val blue = pixel and 0xFF
            
            totalBrightness += (0.299 * red + 0.587 * green + 0.114 * blue)
        }
        
        return totalBrightness / (width * height)
    }
    
    /**
     * Check if region is valid
     */
    private val Rect.isValid: Boolean
        get() = left >= 0 && top >= 0 && right > left && bottom > top
}