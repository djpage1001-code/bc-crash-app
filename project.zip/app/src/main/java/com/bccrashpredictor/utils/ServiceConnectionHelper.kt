package com.bccrashpredictor.utils

import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.ServiceConnection
import android.os.IBinder
import com.bccrashpredictor.service.ScreenCaptureService
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

/**
 * Helper class for managing connection to ScreenCaptureService
 */
class ServiceConnectionHelper(private val context: Context) : ServiceConnection {
    
    private val _isBound = MutableStateFlow(false)
    val isBound: StateFlow<Boolean> = _isBound.asStateFlow()
    
    private var service: ScreenCaptureService? = null
    
    /**
     * Bind to the service
     */
    fun bind() {
        val intent = Intent(context, ScreenCaptureService::class.java)
        context.bindService(intent, this, Context.BIND_AUTO_CREATE)
    }
    
    /**
     * Unbind from the service
     */
    fun unbind() {
        if (_isBound.value) {
            context.unbindService(this)
            _isBound.value = false
            service = null
        }
    }
    
    /**
     * Get the service instance
     */
    fun getService(): ScreenCaptureService? = service
    
    override fun onServiceConnected(name: ComponentName?, binder: IBinder?) {
        // Service is connected
        _isBound.value = true
    }
    
    override fun onServiceDisconnected(name: ComponentName?) {
        _isBound.value = false
        service = null
    }
}