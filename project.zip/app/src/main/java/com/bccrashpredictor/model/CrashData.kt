package com.bccrashpredictor.model

import kotlinx.serialization.Serializable

/**
 * Data class representing a single crash round
 */
@Serializable
data class CrashData(
    val multiplier: Double,
    val timestamp: Long = System.currentTimeMillis(),
    val roundId: String = "",
    val isHighMultiplier: Boolean = multiplier >= 2.0
) {
    companion object {
        fun fromString(text: String): CrashData? {
            // Parse multiplier from text like "2.10x" or "1.20x"
            val regex = Regex("""(\d+\.?\d*)x""")
            val match = regex.find(text)
            return match?.groupValues?.get(1)?.toDoubleOrNull()?.let { multiplier ->
                CrashData(multiplier = multiplier)
            }
        }
    }
}

/**
 * Data class for game region selection
 */
data class GameRegion(
    val left: Int = 0,
    val top: Int = 0,
    val right: Int = 0,
    val bottom: Int = 0
) {
    val width: Int get() = right - left
    val height: Int get() = bottom - top
    val isValid: Boolean get() = width > 0 && height > 0
    
    fun toRect(): android.graphics.Rect {
        return android.graphics.Rect(left, top, right, bottom)
    }
}

/**
 * Data class for prediction results
 */
data class PredictionResult(
    val predictedCrash: Double,
    val confidence: Double,
    val safeCashout: Double,
    val recommendation: String,
    val timestamp: Long = System.currentTimeMillis()
)

/**
 * Data class for OCR extraction results
 */
data class OCRExtraction(
    val liveMultiplier: Double?,
    val historyMultipliers: List<Double>,
    val isRising: Boolean,
    val rawText: String
)

/**
 * Enum for game states
 */
enum class GameState {
    IDLE,
    RISING,
    CRASHED,
    UNKNOWN
}