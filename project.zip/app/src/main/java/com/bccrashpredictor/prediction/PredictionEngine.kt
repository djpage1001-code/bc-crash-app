package com.bccrashpredictor.prediction

import android.util.Log
import com.bccrashpredictor.model.CrashData
import com.bccrashpredictor.model.PredictionResult
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.tensorflow.lite.Interpreter
import java.io.FileInputStream
import java.io.IOException
import java.nio.MappedByteBuffer
import java.nio.channels.FileChannel
import java.nio.FloatBuffer
import kotlin.math.abs
import kotlin.math.pow
import kotlin.math.sqrt
import kotlin.random.Random

/**
 * Prediction Engine for BC Crash game
 * Uses statistical analysis and ML models to predict crash points
 */
class PredictionEngine {
    
    private val TAG = "PredictionEngine"
    
    // Store crash history
    private val crashHistory = mutableListOf<CrashData>()
    private val maxHistorySize = 100
    
    // ML Model interpreter (optional)
    private var tfliteInterpreter: Interpreter? = null
    
    // Statistical parameters
    private val houseEdge = 0.01 // 1% house edge
    private val minMultiplier = 1.0
    private val maxMultiplier = 1000000.0
    
    /**
     * Initialize the prediction engine
     */
    suspend fun initialize() = withContext(Dispatchers.IO) {
        try {
            // Load pre-trained model if available
            // For now, we'll use statistical methods
            Log.d(TAG, "Prediction Engine initialized")
        } catch (e: Exception) {
            Log.e(TAG, "Initialization error: ${e.message}", e)
        }
    }
    
    /**
     * Add crash data to history
     */
    fun addCrashData(crashData: CrashData) {
        crashHistory.add(crashData)
        
        // Maintain max history size
        if (crashHistory.size > maxHistorySize) {
            crashHistory.removeAt(0)
        }
        
        Log.d(TAG, "Added crash data: ${crashData.multiplier}x | History size: ${crashHistory.size}")
    }
    
    /**
     * Get crash history
     */
    fun getCrashHistory(): List<CrashData> {
        return crashHistory.toList()
    }
    
    /**
     * Generate prediction based on historical data
     */
    suspend fun generatePrediction(): PredictionResult = withContext(Dispatchers.Default) {
        if (crashHistory.size < 5) {
            // Not enough data, return default prediction
            return@withContext PredictionResult(
                predictedCrash = 1.98,
                confidence = 20.0,
                safeCashout = 1.5,
                recommendation = "Collecting data... Need more crash history"
            )
        }
        
        // Calculate statistical predictions
        val avgCrash = calculateAverageCrash()
        val medianCrash = calculateMedianCrash()
        val trend = analyzeTrend()
        val streak = detectStreak()
        
        // Combine multiple prediction methods
        val statisticalPrediction = calculateStatisticalPrediction(avgCrash, medianCrash, trend)
        val mlPrediction = calculateMLPrediction()
        
        // Weight the predictions
        val finalPrediction = (statisticalPrediction * 0.7) + (mlPrediction * 0.3)
        
        // Calculate confidence based on data quality
        val confidence = calculateConfidence()
        
        // Calculate safe cashout (80% of prediction with margin)
        val safeCashout = finalPrediction * 0.8
        
        // Generate recommendation
        val recommendation = generateRecommendation(finalPrediction, safeCashout, streak)
        
        PredictionResult(
            predictedCrash = finalPrediction,
            confidence = confidence,
            safeCashout = safeCashout,
            recommendation = recommendation
        )
    }
    
    /**
     * Calculate average crash from history
     */
    private fun calculateAverageCrash(): Double {
        if (crashHistory.isEmpty()) return 1.98
        
        val sum = crashHistory.sumOf { it.multiplier }
        return sum / crashHistory.size
    }
    
    /**
     * Calculate median crash from history
     */
    private fun calculateMedianCrash(): Double {
        if (crashHistory.isEmpty()) return 1.98
        
        val sorted = crashHistory.map { it.multiplier }.sorted()
        val size = sorted.size
        
        return if (size % 2 == 0) {
            (sorted[size / 2 - 1] + sorted[size / 2]) / 2.0
        } else {
            sorted[size / 2]
        }
    }
    
    /**
     * Analyze trend in recent crashes
     */
    private fun analyzeTrend(): Double {
        if (crashHistory.size < 10) return 0.0
        
        val recent = crashHistory.takeLast(10)
        val older = crashHistory.dropLast(10).takeLast(10)
        
        if (older.isEmpty()) return 0.0
        
        val recentAvg = recent.map { it.multiplier }.average()
        val olderAvg = older.map { it.multiplier }.average()
        
        return (recentAvg - olderAvg) / olderAvg
    }
    
    /**
     * Detect streaks in crash patterns
     */
    private fun detectStreak(): String {
        if (crashHistory.size < 5) return "No pattern"
        
        val recent = crashHistory.takeLast(5)
        val lowCount = recent.count { it.multiplier < 1.5 }
        val highCount = recent.count { it.multiplier >= 2.0 }
        
        return when {
            lowCount >= 4 -> "Low streak - expect higher"
            highCount >= 3 -> "High streak - expect lower"
            else -> "Mixed pattern"
        }
    }
    
    /**
     * Calculate statistical prediction
     */
    private fun calculateStatisticalPrediction(
        avgCrash: Double,
        medianCrash: Double,
        trend: Double
    ): Double {
        // Base prediction on average and median
        var prediction = (avgCrash + medianCrash) / 2.0
        
        // Apply trend adjustment
        prediction *= (1.0 + trend * 0.3)
        
        // Apply house edge correction
        prediction *= (1.0 - houseEdge)
        
        // Ensure prediction is within reasonable bounds
        prediction = prediction.coerceIn(1.0, 100.0)
        
        return prediction
    }
    
    /**
     * Calculate ML-based prediction
     * Uses simple pattern matching for now
     */
    private fun calculateMLPrediction(): Double {
        if (crashHistory.size < 10) return 1.98
        
        // Simple pattern: look for repeating sequences
        val recent = crashHistory.takeLast(10).map { it.multiplier }
        
        // Calculate weighted average with more weight on recent data
        var weightedSum = 0.0
        var weightSum = 0.0
        
        recent.forEachIndexed { index, multiplier ->
            val weight = (index + 1).toDouble() // More weight to recent
            weightedSum += multiplier * weight
            weightSum += weight
        }
        
        return weightedSum / weightSum
    }
    
    /**
     * Calculate confidence in prediction
     */
    private fun calculateConfidence(): Double {
        if (crashHistory.size < 10) return 20.0
        
        // More data = higher confidence
        val dataConfidence = (crashHistory.size.toDouble() / maxHistorySize) * 40.0
        
        // Lower variance = higher confidence
        val variance = calculateVariance()
        val varianceConfidence = ((1.0 - variance) * 40.0).coerceAtLeast(0.0)
        
        // Trend consistency
        val trend = analyzeTrend()
        val trendConfidence = (abs(trend) * 20.0).coerceAtMost(20.0)
        
        return (dataConfidence + varianceConfidence + trendConfidence).coerceAtMost(85.0)
    }
    
    /**
     * Calculate variance in crash history
     */
    private fun calculateVariance(): Double {
        if (crashHistory.size < 2) return 1.0
        
        val avg = calculateAverageCrash()
        val variance = crashHistory.map { (it.multiplier - avg).pow(2) }.average()
        
        // Normalize variance
        return (sqrt(variance) / avg).coerceAtMost(1.0)
    }
    
    /**
     * Generate recommendation text
     */
    private fun generateRecommendation(
        prediction: Double,
        safeCashout: Double,
        streak: String
    ): String {
        val baseRecommendation = when {
            prediction < 1.5 -> "Low crash expected - Cashout early at ${String.format("%.2f", safeCashout)}x"
            prediction < 2.0 -> "Moderate crash - Cashout at ${String.format("%.2f", safeCashout)}x"
            prediction < 3.0 -> "Good potential - Cashout at ${String.format("%.2f", safeCashout)}x"
            else -> "High potential - Cashout at ${String.format("%.2f", safeCashout)}x"
        }
        
        return "$baseRecommendation | $streak"
    }
    
    /**
     * Check if current multiplier exceeds safe cashout
     */
    fun shouldCashout(currentMultiplier: Double, safeCashout: Double): Boolean {
        return currentMultiplier >= safeCashout
    }
    
    /**
     * Calculate win rate based on cashout decisions
     */
    fun calculateWinRate(cashoutMultiplier: Double, actualCrash: Double): Boolean {
        return cashoutMultiplier <= actualCrash
    }
    
    /**
     * Export crash history to CSV format
     */
    fun exportToCSV(): String {
        val header = "RoundID,Multiplier,Timestamp,IsHighMultiplier\n"
        val rows = crashHistory.joinToString("\n") { data ->
            "${data.roundId},${data.multiplier},${data.timestamp},${data.isHighMultiplier}"
        }
        return header + rows
    }
    
    /**
     * Clear crash history
     */
    fun clearHistory() {
        crashHistory.clear()
        Log.d(TAG, "Crash history cleared")
    }
    
    /**
     * Get statistics summary
     */
    fun getStatistics(): Map<String, Any> {
        if (crashHistory.isEmpty()) {
            return mapOf(
                "totalCrashes" to 0,
                "averageCrash" to 0.0,
                "medianCrash" to 0.0,
                "highMultiplierCount" to 0,
                "lowMultiplierCount" to 0
            )
        }
        
        val avg = calculateAverageCrash()
        val median = calculateMedianCrash()
        val highCount = crashHistory.count { it.multiplier >= 2.0 }
        val lowCount = crashHistory.count { it.multiplier < 1.5 }
        
        return mapOf(
            "totalCrashes" to crashHistory.size,
            "averageCrash" to String.format("%.2f", avg),
            "medianCrash" to String.format("%.2f", median),
            "highMultiplierCount" to highCount,
            "lowMultiplierCount" to lowCount
        )
    }
    
    /**
     * Clean up resources
     */
    fun close() {
        tfliteInterpreter?.close()
        tfliteInterpreter = null
    }
}