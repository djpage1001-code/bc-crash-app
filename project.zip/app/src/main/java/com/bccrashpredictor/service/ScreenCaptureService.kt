package com.bccrashpredictor.service

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.Image
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.util.DisplayMetrics
import android.util.Log
import android.view.Gravity
import android.view.WindowManager
import android.widget.Toast
import androidx.core.app.NotificationCompat
import com.bccrashpredictor.MainActivity
import com.bccrashpredictor.R
import com.bccrashpredictor.model.CrashData
import com.bccrashpredictor.model.GameRegion
import com.bccrashpredictor.model.GameState
import com.bccrashpredictor.ocr.OCRProcessor
import com.bccrashpredictor.prediction.PredictionEngine
import kotlinx.coroutines.*
import java.io.ByteArrayOutputStream
import java.nio.ByteBuffer

/**
 * Foreground Service for continuous screen capture
 * Captures screen at 10 FPS and processes crash game data
 */
class ScreenCaptureService : Service() {
    
    companion object {
        private const val TAG = "ScreenCaptureService"
        private const val NOTIFICATION_ID = 1001
        private const val CHANNEL_ID = "BC_Crash_Predictor_Channel"
        private const val CHANNEL_NAME = "BC Crash Predictor"
        
        const val ACTION_START = "com.bccrashpredictor.START_CAPTURE"
        const val ACTION_STOP = "com.bccrashpredictor.STOP_CAPTURE"
        const val ACTION_SET_REGION = "com.bccrashpredictor.SET_REGION"
        const val EXTRA_RESULT_CODE = "RESULT_CODE"
        const val EXTRA_DATA = "DATA"
        
        const val CAPTURE_FPS = 10
        const val CAPTURE_INTERVAL_MS = 1000L / CAPTURE_FPS
    }
    
    private var mediaProjection: MediaProjection? = null
    private var virtualDisplay: VirtualDisplay? = null
    private var imageReader: ImageReader? = null
    
    private val ocrProcessor = OCRProcessor()
    private val predictionEngine = PredictionEngine()
    
    private var captureJob: Job? = null
    private var isCapturing = false
    
    private var gameRegion: GameRegion? = null
    private var currentGameState = GameState.IDLE
    private var lastMultiplier = 0.0
    private var currentMultiplier = 0.0
    
    private val serviceScope = CoroutineScope(Dispatchers.Main + SupervisorJob())
    
    // Callbacks for UI updates
    var onFrameCaptured: ((Bitmap) -> Unit)? = null
    var onOCRResult: ((Double, List<Double>) -> Unit)? = null
    var onPredictionUpdate: ((String, Double, Double) -> Unit)? = null
    var onGameStateChange: ((GameState) -> Unit)? = null
    var onAlertTriggered: (() -> Unit)? = null
    
    override fun onCreate() {
        super.onCreate()
        Log.d(TAG, "Service created")
        createNotificationChannel()
        serviceScope.launch {
            predictionEngine.initialize()
        }
    }
    
    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_START -> {
                val resultCode = intent.getIntExtra(EXTRA_RESULT_CODE, -1)
                val data = intent.getParcelableExtra<Intent>(EXTRA_DATA)
                if (resultCode != -1 && data != null) {
                    startCapture(resultCode, data)
                }
            }
            ACTION_STOP -> {
                stopCapture()
            }
            ACTION_SET_REGION -> {
                val region = intent.getSerializableExtra("region") as? GameRegion
                if (region != null) {
                    gameRegion = region
                    Log.d(TAG, "Game region set: $region")
                    Toast.makeText(this, "Game region updated", Toast.LENGTH_SHORT).show()
                }
            }
        }
        return START_STICKY
    }
    
    override fun onBind(intent: Intent?): IBinder? {
        return null
    }
    
    /**
     * Start screen capture
     */
    private fun startCapture(resultCode: Int, data: Intent) {
        if (isCapturing) {
            Log.w(TAG, "Already capturing")
            return
        }
        
        try {
            val mediaProjectionManager = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
            mediaProjection = mediaProjectionManager.getMediaProjection(resultCode, data)
            
            // Create ImageReader for capturing frames
            val windowManager = getSystemService(Context.WINDOW_SERVICE) as WindowManager
            val displayMetrics = DisplayMetrics()
            windowManager.defaultDisplay.getMetrics(displayMetrics)
            
            val width = displayMetrics.widthPixels
            val height = displayMetrics.heightPixels
            val density = displayMetrics.densityDpi
            
            imageReader = ImageReader.newInstance(width, height, PixelFormat.RGBA_8888, 2)
            
            // Create VirtualDisplay
            virtualDisplay = mediaProjection?.createVirtualDisplay(
                "BC Crash Predictor",
                width, height, density,
                DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
                imageReader?.surface,
                null,
                null
            )
            
            isCapturing = true
            startForeground(NOTIFICATION_ID, createNotification())
            
            // Start capture loop
            startCaptureLoop()
            
            Log.d(TAG, "Screen capture started")
            Toast.makeText(this, "Screen capture started", Toast.LENGTH_SHORT).show()
            
        } catch (e: Exception) {
            Log.e(TAG, "Error starting capture: ${e.message}", e)
            stopSelf()
        }
    }
    
    /**
     * Start the capture loop
     */
    private fun startCaptureLoop() {
        captureJob = serviceScope.launch(Dispatchers.IO) {
            while (isCapturing) {
                try {
                    captureFrame()
                    delay(CAPTURE_INTERVAL_MS)
                } catch (e: Exception) {
                    Log.e(TAG, "Capture loop error: ${e.message}", e)
                    delay(1000) // Wait before retrying
                }
            }
        }
    }
    
    /**
     * Capture a single frame
     */
    private suspend fun captureFrame() {
        val image = imageReader?.acquireLatestImage() ?: return
        
        try {
            val bitmap = imageToBitmap(image)
            
            // Send frame to UI
            onFrameCaptured?.invoke(bitmap)
            
            // Process frame with OCR
            processFrame(bitmap)
            
        } catch (e: Exception) {
            Log.e(TAG, "Error processing frame: ${e.message}", e)
        } finally {
            image.close()
        }
    }
    
    /**
     * Convert Image to Bitmap
     */
    private fun imageToBitmap(image: Image): Bitmap {
        val planes = image.planes
        val buffer = planes[0].buffer
        val pixelStride = planes[0].pixelStride
        val rowStride = planes[0].rowStride
        val rowPadding = rowStride - pixelStride * image.width
        
        val bitmap = Bitmap.createBitmap(
            image.width + rowPadding / pixelStride,
            image.height,
            Bitmap.Config.ARGB_8888
        )
        
        bitmap.copyPixelsFromBuffer(buffer)
        
        // Crop to actual size if needed
        if (rowPadding != 0) {
            return Bitmap.createBitmap(bitmap, 0, 0, image.width, image.height)
        }
        
        return bitmap
    }
    
    /**
     * Process frame with OCR and prediction
     */
    private suspend fun processFrame(bitmap: Bitmap) {
        try {
            // Perform OCR
            val extraction = ocrProcessor.processFrame(bitmap, gameRegion?.toRect())
            
            if (extraction.liveMultiplier != null) {
                currentMultiplier = extraction.liveMultiplier
                
                // Send OCR results to UI
                onOCRResult?.invoke(currentMultiplier, extraction.historyMultipliers)
                
                // Detect game state changes
                detectGameStateChange(extraction)
                
                // Generate prediction if game is idle or just crashed
                if (currentGameState == GameState.IDLE || currentGameState == GameState.CRASHED) {
                    generatePrediction()
                }
                
                // Check for cashout alert
                checkCashoutAlert()
            }
            
        } catch (e: Exception) {
            Log.e(TAG, "Error processing frame: ${e.message}", e)
        }
    }
    
    /**
     * Detect changes in game state
     */
    private fun detectGameStateChange(extraction: com.bccrashpredictor.model.OCRExtraction) {
        val newState = when {
            extraction.isRising && extraction.liveMultiplier != null -> GameState.RISING
            !extraction.isRising && extraction.liveMultiplier != null && extraction.liveMultiplier <= 1.0 -> GameState.CRASHED
            else -> GameState.UNKNOWN
        }
        
        if (newState != currentGameState && newState != GameState.UNKNOWN) {
            val oldState = currentGameState
            currentGameState = newState
            
            Log.d(TAG, "Game state changed: $oldState -> $newState")
            onGameStateChange?.invoke(newState)
            
            // If game crashed, add to history
            if (newState == GameState.CRASHED && lastMultiplier > 1.0) {
                val crashData = CrashData(
                    multiplier = lastMultiplier,
                    roundId = System.currentTimeMillis().toString()
                )
                predictionEngine.addCrashData(crashData)
                Log.d(TAG, "Crash recorded: ${lastMultiplier}x")
            }
        }
        
        // Update last multiplier if rising
        if (currentGameState == GameState.RISING) {
            lastMultiplier = currentMultiplier
        }
    }
    
    /**
     * Generate prediction
     */
    private suspend fun generatePrediction() {
        val prediction = predictionEngine.generatePrediction()
        
        val message = "Predicted: ${String.format("%.2f", prediction.predictedCrash)}x " +
                     "(Conf: ${String.format("%.0f", prediction.confidence)}%)"
        
        onPredictionUpdate?.invoke(
            message,
            prediction.predictedCrash,
            prediction.safeCashout
        )
        
        Log.d(TAG, "Prediction: $message")
    }
    
    /**
     * Check if cashout alert should be triggered
     */
    private fun checkCashoutAlert() {
        if (currentGameState != GameState.RISING) return
        
        val prediction = predictionEngine.generatePrediction()
        
        if (predictionEngine.shouldCashout(currentMultiplier, prediction.safeCashout)) {
            Log.d(TAG, "Cashout alert triggered at ${currentMultiplier}x")
            onAlertTriggered?.invoke()
        }
    }
    
    /**
     * Stop screen capture
     */
    private fun stopCapture() {
        isCapturing = false
        captureJob?.cancel()
        
        virtualDisplay?.release()
        virtualDisplay = null
        
        mediaProjection?.stop()
        mediaProjection = null
        
        imageReader?.close()
        imageReader = null
        
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
        
        Log.d(TAG, "Screen capture stopped")
    }
    
    /**
     * Create notification channel
     */
    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                CHANNEL_NAME,
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "BC Crash Predictor Screen Capture Service"
                setShowBadge(false)
            }
            
            val notificationManager = getSystemService(NotificationManager::class.java)
            notificationManager.createNotificationChannel(channel)
        }
    }
    
    /**
     * Create notification for foreground service
     */
    private fun createNotification(): Notification {
        val intent = Intent(this, MainActivity::class.java)
        val pendingIntent = PendingIntent.getActivity(
            this,
            0,
            intent,
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("BC Crash Predictor")
            .setContentText("Screen capture active")
            .setSmallIcon(R.drawable.ic_notification)
            .setContentIntent(pendingIntent)
            .setOngoing(true)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .build()
    }
    
    override fun onDestroy() {
        super.onDestroy()
        stopCapture()
        ocrProcessor.close()
        predictionEngine.close()
        serviceScope.cancel()
        Log.d(TAG, "Service destroyed")
    }
}