package com.bccrashpredictor.ocr

import android.graphics.Bitmap
import android.graphics.Rect
import android.util.Log
import com.bccrashpredictor.model.OCRExtraction
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/**
 * OCR Processor for extracting crash game data from screenshots
 * Uses Google ML Kit Text Recognition API
 */
class OCRProcessor {
    
    private val TAG = "OCRProcessor"
    private val textRecognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
    
    // Regex patterns for extracting multipliers
    private val multiplierPattern = Regex("""(\d+\.?\d*)x""")
    private val crashPattern = Regex("""crashed|crash""", RegexOption.IGNORE_CASE)
    
    /**
     * Process a bitmap frame and extract crash game data
     */
    suspend fun processFrame(
        bitmap: Bitmap,
        gameRegion: Rect? = null
    ): OCRExtraction = withContext(Dispatchers.Default) {
        try {
            // Crop to game region if specified
            val processedBitmap = if (gameRegion != null && gameRegion.isValid) {
                Bitmap.createBitmap(
                    bitmap,
                    gameRegion.left,
                    gameRegion.top,
                    gameRegion.width(),
                    gameRegion.height()
                )
            } else {
                bitmap
            }
            
            // Preprocess image for better OCR
            val preprocessedBitmap = preprocessImage(processedBitmap)
            
            // Create InputImage from bitmap
            val image = InputImage.fromBitmap(preprocessedBitmap, 0)
            
            // Perform text recognition
            val result = textRecognizer.process(image).await()
            val fullText = result.text
            
            Log.d(TAG, "OCR Result: $fullText")
            
            // Extract live multiplier from center region
            val liveMultiplier = extractLiveMultiplier(fullText)
            
            // Extract crash history
            val historyMultipliers = extractHistoryMultipliers(fullText)
            
            // Determine game state
            val isRising = determineGameState(fullText, liveMultiplier)
            
            OCRExtraction(
                liveMultiplier = liveMultiplier,
                historyMultipliers = historyMultipliers,
                isRising = isRising,
                rawText = fullText
            )
            
        } catch (e: Exception) {
            Log.e(TAG, "OCR processing error: ${e.message}", e)
            OCRExtraction(
                liveMultiplier = null,
                historyMultipliers = emptyList(),
                isRising = false,
                rawText = ""
            )
        }
    }
    
    /**
     * Preprocess image for better OCR accuracy
     * Converts to grayscale and applies threshold
     */
    private fun preprocessImage(bitmap: Bitmap): Bitmap {
        val width = bitmap.width
        val height = bitmap.height
        val pixels = IntArray(width * height)
        
        // Get pixels
        bitmap.getPixels(pixels, 0, width, 0, 0, width, height)
        
        // Convert to grayscale and apply threshold
        for (i in pixels.indices) {
            val pixel = pixels[i]
            val red = (pixel shr 16) and 0xFF
            val green = (pixel shr 8) and 0xFF
            val blue = pixel and 0xFF
            
            // Grayscale conversion
            val gray = (0.299 * red + 0.587 * green + 0.114 * blue).toInt()
            
            // Threshold for better text contrast
            val threshold = 128
            val binary = if (gray > threshold) 255 else 0
            
            // Set back to pixel (grayscale)
            pixels[i] = (binary shl 16) or (binary shl 8) or binary or 0xFF000000.toInt()
        }
        
        // Create new bitmap with processed pixels
        val processedBitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
        processedBitmap.setPixels(pixels, 0, width, 0, 0, width, height)
        
        return processedBitmap
    }
    
    /**
     * Extract live multiplier from text
     * Looks for patterns like "2.10x" or "1.50x"
     */
    private fun extractLiveMultiplier(text: String): Double? {
        val matches = multiplierPattern.findAll(text)
        
        // Find the largest multiplier (likely the live one)
        val multipliers = matches.mapNotNull { it.groupValues[1].toDoubleOrNull() }.toList()
        
        return if (multipliers.isNotEmpty()) {
            multipliers.maxOrNull()
        } else {
            null
        }
    }
    
    /**
     * Extract crash history multipliers from text
     * Returns list of multipliers found in the text
     */
    private fun extractHistoryMultipliers(text: String): List<Double> {
        val matches = multiplierPattern.findAll(text)
        return matches.mapNotNull { match ->
            match.groupValues[1].toDoubleOrNull()
        }.toList()
    }
    
    /**
     * Determine if game is currently rising or crashed
     */
    private fun determineGameState(text: String, liveMultiplier: Double?): Boolean {
        // Check for crash indicators
        if (crashPattern.containsMatchIn(text)) {
            return false
        }
        
        // If we have a live multiplier > 1.0, it's likely rising
        if (liveMultiplier != null && liveMultiplier > 1.0) {
            return true
        }
        
        return false
    }
    
    /**
     * Extract multiplier from specific region (ROI)
     */
    suspend fun extractMultiplierFromROI(
        bitmap: Bitmap,
        roi: Rect
    ): Double? = withContext(Dispatchers.Default) {
        try {
            if (!roi.isValid || roi.left < 0 || roi.top < 0 || 
                roi.right > bitmap.width || roi.bottom > bitmap.height) {
                return@withContext null
            }
            
            // Crop to ROI
            val croppedBitmap = Bitmap.createBitmap(
                bitmap,
                roi.left,
                roi.top,
                roi.width(),
                roi.height()
            )
            
            // Process ROI
            val extraction = processFrame(croppedBitmap, null)
            extraction.liveMultiplier
            
        } catch (e: Exception) {
            Log.e(TAG, "ROI extraction error: ${e.message}", e)
            null
        }
    }
    
    /**
     * Clean up resources
     */
    fun close() {
        textRecognizer.close()
    }
}