package com.bccrashpredictor

import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.media.MediaScannerConnection
import android.os.Environment
import android.widget.Toast
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.bccrashpredictor.model.GameState
import com.bccrashpredictor.service.ScreenCaptureService
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import java.io.File
import java.io.FileOutputStream

/**
 * ViewModel for MainActivity
 * Manages UI state and coordinates with ScreenCaptureService
 */
class MainViewModel : ViewModel() {
    
    private val _uiState = MutableStateFlow(UiState())
    val uiState: StateFlow<UiState> = _uiState.asStateFlow()
    
    private var frameCount = 0
    private var lastFpsUpdate = System.currentTimeMillis()
    
    init {
        setupServiceCallbacks()
    }
    
    /**
     * Setup callbacks from ScreenCaptureService
     */
    private fun setupServiceCallbacks() {
        // These will be set when service is bound
        // For now, we'll simulate updates
    }
    
    /**
     * Handle permissions granted
     */
    fun onPermissionsGranted() {
        _uiState.value = _uiState.value.copy(
            isPermissionsGranted = true
        )
    }
    
    /**
     * Start screen capture
     */
    fun startScreenCapture(resultCode: Int, data: Intent) {
        val intent = Intent(App.instance, ScreenCaptureService::class.java).apply {
            action = ScreenCaptureService.ACTION_START
            putExtra(ScreenCaptureService.EXTRA_RESULT_CODE, resultCode)
            putExtra(ScreenCaptureService.EXTRA_DATA, data)
        }
        
        App.instance.startService(intent)
        
        _uiState.value = _uiState.value.copy(
            isCapturing = true
        )
        
        // Start FPS counter
        startFpsCounter()
    }
    
    /**
     * Stop screen capture
     */
    fun stopScreenCapture() {
        val intent = Intent(App.instance, ScreenCaptureService::class.java).apply {
            action = ScreenCaptureService.ACTION_STOP
        }
        
        App.instance.startService(intent)
        
        _uiState.value = _uiState.value.copy(
            isCapturing = false,
            currentMultiplier = 0.0,
            gameState = GameState.IDLE
        )
    }
    
    /**
     * Update captured frame
     */
    fun onFrameCaptured(bitmap: Bitmap) {
        _uiState.value = _uiState.value.copy(
            capturedFrame = bitmap
        )
        frameCount++
    }
    
    /**
     * Update OCR results
     */
    fun onOCRResult(multiplier: Double, history: List<Double>) {
        _uiState.value = _uiState.value.copy(
            currentMultiplier = multiplier,
            crashHistory = history.takeLast(50) // Keep last 50
        )
    }
    
    /**
     * Update prediction
     */
    fun onPredictionUpdate(message: String, prediction: Double, safeCashout: Double) {
        _uiState.value = _uiState.value.copy(
            prediction = prediction,
            safeCashout = safeCashout,
            predictionMessage = message
        )
    }
    
    /**
     * Update game state
     */
    fun onGameStateChange(state: GameState) {
        _uiState.value = _uiState.value.copy(
            gameState = state
        )
    }
    
    /**
     * Trigger alert
     */
    fun onAlertTriggered() {
        _uiState.value = _uiState.value.copy(
            shouldAlert = true
        )
    }
    
    /**
     * Handle alert
     */
    fun onAlertHandled() {
        _uiState.value = _uiState.value.copy(
            shouldAlert = false
        )
    }
    
    /**
     * Update statistics
     */
    fun updateStatistics(stats: Map<String, Any>) {
        _uiState.value = _uiState.value.copy(
            statistics = stats
        )
    }
    
    /**
     * Start FPS counter
     */
    private fun startFpsCounter() {
        viewModelScope.launch {
            while (_uiState.value.isCapturing) {
                delay(1000)
                val currentTime = System.currentTimeMillis()
                val elapsed = currentTime - lastFpsUpdate
                val fps = if (elapsed > 0) {
                    (frameCount * 1000) / elapsed
                } else {
                    0
                }
                
                _uiState.value = _uiState.value.copy(fps = fps.toInt())
                
                frameCount = 0
                lastFpsUpdate = currentTime
            }
        }
    }
    
    /**
     * Export history to CSV
     */
    fun exportHistory(context: Context) {
        viewModelScope.launch {
            try {
                val history = _uiState.value.crashHistory
                if (history.isEmpty()) {
                    Toast.makeText(context, "No history to export", Toast.LENGTH_SHORT).show()
                    return@launch
                }
                
                // Create CSV content
                val csvContent = buildString {
                    appendLine("Index,Multiplier")
                    history.forEachIndexed { index, multiplier ->
                        appendLine("$index,$multiplier")
                    }
                }
                
                // Save to file
                val fileName = "bc_crash_history_${System.currentTimeMillis()}.csv"
                val downloadsDir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS)
                val file = File(downloadsDir, fileName)
                
                FileOutputStream(file).use { output ->
                    output.write(csvContent.toByteArray())
                }
                
                // Notify media scanner
                MediaScannerConnection.scanFile(
                    context,
                    arrayOf(file.absolutePath),
                    null
                ) { path, uri ->
                    Toast.makeText(
                        context,
                        "Exported to $path",
                        Toast.LENGTH_LONG
                    ).show()
                }
                
            } catch (e: Exception) {
                Toast.makeText(
                    context,
                    "Export failed: ${e.message}",
                    Toast.LENGTH_SHORT
                ).show()
            }
        }
    }
    
    override fun onCleared() {
        super.onCleared()
        stopScreenCapture()
    }
}

/**
 * UI State data class
 */
data class UiState(
    val isCapturing: Boolean = false,
    val isPermissionsGranted: Boolean = false,
    val capturedFrame: Bitmap? = null,
    val currentMultiplier: Double = 0.0,
    val gameState: GameState = GameState.IDLE,
    val fps: Int = 0,
    val prediction: Double = 0.0,
    val safeCashout: Double = 0.0,
    val confidence: Double = 0.0,
    val predictionMessage: String = "",
    val crashHistory: List<Double> = emptyList(),
    val statistics: Map<String, Any> = emptyMap(),
    val shouldAlert: Boolean = false
)

/**
 * Application class for global context
 */
class App : android.app.Application() {
    companion object {
        lateinit var instance: App
            private set
    }
    
    override fun onCreate() {
        super.onCreate()
        instance = this
    }
}