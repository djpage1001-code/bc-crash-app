# BC Crash Predictor - Android App

A complete Android application that continuously screen records the BC.Game Crash game interface, uses OCR to extract live multiplier and crash history, analyzes patterns, and predicts optimal cashout points with real-time alerts.

## ⚠️ DISCLAIMER

**Predictions are statistical aids ONLY. Gambling is risky - BC Crash is RNG (Random Number Generator). No guarantees. Use responsibly.**

## Features

- **Real-time Screen Capture**: Continuous capture at 10 FPS using MediaProjection API
- **OCR Text Recognition**: Extracts live multipliers and crash history using Google ML Kit
- **Pattern Analysis**: Statistical analysis of crash history with trend detection
- **ML Predictions**: Lightweight prediction engine using statistical methods
- **Real-time Alerts**: Audio and visual alerts when safe cashout point is reached
- **Modern UI**: Jetpack Compose with Material Design 3
- **Data Visualization**: Interactive charts showing crash history
- **Export Functionality**: Export crash history to CSV
- **Privacy-focused**: All processing is done locally, no cloud services

## Requirements

- Android Studio Hedgehog (2023.1.1) or later
- Android SDK API 29+ (Android 10)
- Kotlin 1.9.0+
- Gradle 8.0+

## Project Structure

```
app/
├── src/main/
│   ├── java/com/bccrashpredictor/
│   │   ├── MainActivity.kt              # Main activity with Jetpack Compose UI
│   │   ├── MainViewModel.kt             # ViewModel for state management
│   │   ├── model/                       # Data models
│   │   │   └── CrashData.kt
│   │   ├── ocr/                         # OCR processing
│   │   │   └── OCRProcessor.kt
│   │   ├── prediction/                  # Prediction engine
│   │   │   └── PredictionEngine.kt
│   │   ├── service/                     # Foreground service
│   │   │   └── ScreenCaptureService.kt
│   │   └── ui/theme/                    # UI theme
│   ├── res/                             # Resources
│   └── AndroidManifest.xml
├── build.gradle.kts                     # App-level build configuration
└── proguard-rules.pro
```

## Setup Instructions

### 1. Clone or Download the Project

```bash
git clone <repository-url>
cd bc-crash-predictor
```

### 2. Open in Android Studio

1. Launch Android Studio
2. Select "Open an Existing Project"
3. Navigate to the project directory and select it
4. Wait for Gradle sync to complete

### 3. Configure Build Settings

The project uses Kotlin DSL for Gradle. Ensure your `gradle.properties` has:

```properties
org.gradle.jvmargs=-Xmx2048m -Dfile.encoding=UTF-8
android.useAndroidX=true
android.enableJetifier=true
kotlin.code.style=official
```

### 4. Sync Dependencies

Click "Sync Project with Gradle Files" in Android Studio or run:

```bash
./gradlew build
```

## Building the App

### Debug Build

```bash
./gradlew assembleDebug
```

The APK will be located at: `app/build/outputs/apk/debug/app-debug.apk`

### Release Build

```bash
./gradlew assembleRelease
```

The APK will be located at: `app/build/outputs/apk/release/app-release.apk`

## Running the App

### Using Android Studio

1. Connect an Android device (API 29+) or start an emulator
2. Click the "Run" button (▶️) or press `Shift + F10`
3. Select your target device
4. The app will install and launch automatically

### Using ADB

```bash
# Install debug APK
adb install app/build/outputs/apk/debug/app-debug.apk

# Launch the app
adb shell am start -n com.bccrashpredictor/.MainActivity
```

## Usage Guide

### 1. Grant Permissions

On first launch, the app will request:
- **Foreground Service**: Required for continuous screen capture
- **Post Notifications**: For alerts and service notifications
- **Screen Capture**: Permission to capture screen content

### 2. Start Screen Capture

1. Tap the "Start Capture" button
2. Grant screen capture permission when prompted
3. The app will start capturing the screen at 10 FPS

### 3. Select Game Region (Optional)

1. Tap "Select Region" button
2. Draw a rectangle around the BC.Game Crash interface
3. The app will focus OCR on this region for better accuracy

### 4. Monitor Predictions

- **Live Preview**: See captured frames in real-time
- **Game Status**: Current multiplier and game state (Rising/Crashed)
- **Prediction**: Predicted crash point with confidence level
- **Safe Cashout**: Recommended cashout point (80% of prediction)
- **Alerts**: Audio/visual alert when current multiplier exceeds safe cashout

### 5. View Statistics

- Total crashes recorded
- Average crash multiplier
- Median crash multiplier
- High/low multiplier counts

### 6. Export Data

Tap "Export History to CSV" to save crash history to your device's Downloads folder.

## Technical Details

### Screen Capture

- Uses `MediaProjection` API for screen capture
- Captures at 10 FPS (100ms intervals)
- Runs in a `ForegroundService` for continuous operation
- Supports region selection for focused OCR

### OCR Processing

- Uses Google ML Kit Text Recognition API
- Preprocesses images (grayscale, threshold) for better accuracy
- Extracts multipliers using regex pattern: `(\d+\.?\d*)x`
- Detects game state (Rising/Crashed) from text

### Prediction Engine

- **Statistical Analysis**: Average, median, trend detection
- **Pattern Recognition**: Streak detection (low/high sequences)
- **Confidence Calculation**: Based on data quality and variance
- **Safe Cashout**: 80% of predicted value with margin

### Performance

- Optimized for 10 FPS capture
- Minimal battery impact
- Low memory footprint
- All processing done on-device

## Dependencies

### Core Android
- `androidx.core:core-ktx`
- `androidx.lifecycle:lifecycle-runtime-ktx`
- `androidx.activity:activity-compose`

### UI
- `androidx.compose.ui:ui`
- `androidx.compose.material3:material3`
- `androidx.navigation:navigation-compose`

### ML & OCR
- `com.google.mlkit:text-recognition`
- `org.tensorflow:tensorflow-lite`

### Charts
- `com.github.PhilJay:MPAndroidChart`

### Coroutines
- `org.jetbrains.kotlinx:kotlinx-coroutines-android`

## Troubleshooting

### Screen Capture Not Working

- Ensure you've granted screen capture permission
- Check if the app has foreground service permission
- Try restarting the app
- Verify Android version is API 29+

### OCR Not Detecting Multipliers

- Adjust game region selection
- Ensure good lighting and contrast
- Check if the game interface is visible
- Try different screen orientations

### Predictions Inaccurate

- Collect more crash history (minimum 10 rounds)
- Ensure consistent game region selection
- Check for UI changes in the game
- Remember: BC Crash is RNG-based

### App Crashes

- Check Android logcat for error messages
- Ensure sufficient device storage
- Verify all permissions are granted
- Try clearing app cache

## Privacy & Security

- **Local Processing**: All OCR and prediction done on-device
- **No Cloud Services**: No data sent to external servers
- **No Tracking**: No analytics or user tracking
- **Open Source**: Code is transparent and auditable

## Limitations

- Requires Android 10+ (API 29)
- Screen capture permission required each session
- OCR accuracy depends on game interface visibility
- Predictions are statistical estimates, not guarantees
- Battery usage during continuous capture

## Future Enhancements

- [ ] Machine learning model training
- [ ] Custom prediction algorithms
- [ ] Multiple game support
- [ ] Cloud sync for history
- [ ] Advanced analytics dashboard
- [ ] Custom alert sounds
- [ ] Widget support

## License

This project is provided as-is for educational purposes. Use responsibly and at your own risk.

## Contributing

Contributions are welcome! Please feel free to submit issues or pull requests.

## Support

For issues or questions:
1. Check the troubleshooting section
2. Review Android logcat for errors
3. Ensure all requirements are met
4. Contact support if needed

## Version History

- **v1.0.0** - Initial release
  - Screen capture functionality
  - OCR text recognition
  - Statistical predictions
  - Jetpack Compose UI
  - CSV export

---

**Remember: Gambling involves risk. Never bet more than you can afford to lose. This app is for analysis purposes only.**